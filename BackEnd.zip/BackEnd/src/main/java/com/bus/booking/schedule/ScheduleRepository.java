package com.bus.booking.schedule;

import org.springframework.data.jpa.repository.JpaRepository;

public interface ScheduleRepository extends JpaRepository<Schedule, Integer> {
    
    Schedule findByStartingpointAndDestinationAndDate(String startingpoint, String destination, String date);
    
    Schedule findByDestination(String destination);

}
