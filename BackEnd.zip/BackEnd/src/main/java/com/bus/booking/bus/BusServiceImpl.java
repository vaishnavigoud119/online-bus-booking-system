package com.bus.booking.bus;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;


import java.util.List;

@Repository
public class BusServiceImpl implements BusService {   

    @Autowired
    private BusRepository busRepository;
	@Override
	public int register(Bus bus) {
		busRepository.save(bus);
        return bus.getId();
	}

	@Override
	public boolean update(Bus busNew) {
		
		 Bus busOld = busRepository.findById(busNew.getId()).orElse(null);
	        if (busOld != null) {
	            busOld.setName(busNew.getName());
	            busOld.setNumber(busNew.getNumber());
	            busRepository.save(busOld);
	            return true;
	        }
	        return false;
		
	}

	@Override
	public Bus getBus(int busID) {
		return busRepository.findById(busID).orElse(null);
	}

	@Override
	public List<Bus> getAllBuses() {
		return busRepository.findAll();
	}
	
	@Override
    public boolean delete(int busID) {
        Bus bus = busRepository.findById(busID).orElse(null);
        if (bus != null) {
            busRepository.delete(bus);
            return true;
        }
        return false;
    }

	
	@Override
	public Bus findByNumber(String number) {
		if (busRepository.findByNumber(number) != null) {
            return busRepository.findByNumber(number);
        }
        return new Bus(); 
	} 

	@Override
	public Bus findByName(String name) {
		if (busRepository.findByName(name) != null) {
            return busRepository.findByName(name);
        }
        return new Bus();
	}
	
}
