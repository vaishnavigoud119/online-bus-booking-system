package com.bus.booking.bus;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;


@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class BusController {
    
    @Autowired
    private BusService busService;

    
    @PostMapping(value="/bus/registration", consumes="application/json")
    public int registerBus(@RequestBody Bus bus){
        return busService.register(bus);
    }

    
    @GetMapping(value="/bus/get/{busID}", produces="application/json")
    public Bus getBusByID(@PathVariable int busID) {
        return busService.getBus(busID);
    }

    
    @GetMapping(value="/bus/listAll", produces="application/json")
    public List<Bus> getAllBuses() {
        return busService.getAllBuses();
    }

    @PutMapping(value="/bus/update", consumes="application/json")
    public boolean updateBus(@RequestBody Bus bus) {
        return busService.update(bus);
    }

    @DeleteMapping(value="/bus/delete/{busID}")
    public boolean deleteBus(@PathVariable int busID) {
        return busService.delete(busID);
    }    
}
