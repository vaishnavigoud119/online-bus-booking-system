package com.bus.booking.bus;

import org.springframework.data.jpa.repository.JpaRepository;

public interface BusRepository extends JpaRepository<Bus, Integer> {
    
    Bus findByNumber(String number);
    Bus findByName(String name);
}
