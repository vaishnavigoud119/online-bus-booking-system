package com.bus.booking.bus;


import java.util.List;

public interface BusService {

    
    int register(Bus bus);

    boolean update(Bus bus);

    Bus getBus(int busID);
    
    List<Bus> getAllBuses();

    boolean delete(int busID);
    
   
    Bus findByNumber(String number);
    
   
    Bus findByName(String name);

}
